﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using CareerHub.Exceptions;

namespace CareerHub.Util
{
    public static class DBConnUtil
    {
        public static SqlConnection GetConnection(string configFileName)
        {
            try
            {
                string connStr = DBPropertyUtil.GetConnectionString(configFileName);
                return new SqlConnection(connStr);
            }
            catch (Exception ex)
            {
                throw new DatabaseConnectionException("Failed to connect to DB: " + ex.Message);
            }
        }
    }
}
