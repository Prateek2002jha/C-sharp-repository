﻿using Microsoft.Extensions.Configuration;
using System.IO;

public class DBPropertyUtil
{
    public static string GetConnectionString(string configFile)
    {
        try
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())  // Current directory = bin/debug...
                .AddJsonFile(configFile, optional: false, reloadOnChange: true);

            IConfigurationRoot configuration = builder.Build();
            return configuration.GetConnectionString("DefaultConnection");
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to connect to DB: Failed to load configuration from file '{configFile}'.", ex);
        }
    }
}
