﻿using System;
using CareerHub.Entity;
using CareerHub.Exceptions;
using dao;

class MainModule
{
    static void Main()
    {
        DatabaseManager db = new DatabaseManager();

        while (true)
        {
            Console.WriteLine("\nCareerHub - Select an Option:");
            Console.WriteLine("1. View All Job Listings");
            Console.WriteLine("2. Create Applicant Profile");
            Console.WriteLine("3. Apply for Job");
            Console.WriteLine("4. Post a Job (Company)");
            Console.WriteLine("5. Search Jobs by Salary Range");
            Console.WriteLine("0. Exit");
            Console.Write("Choice: ");

            if (!int.TryParse(Console.ReadLine(), out int choice))
            {
                Console.WriteLine("❌ Invalid input. Please enter a number.");
                continue;
            }

            try
            {
                switch (choice)
                {
                    case 1:
                        var jobs = db.GetJobListingsWithCompany();
                        if (jobs.Count == 0)
                        {
                            Console.WriteLine("⚠️ No job listings found.");
                        }
                        else
                        {
                            foreach (var j in jobs)
                                Console.WriteLine($"{j.JobTitle} at {j.CompanyName} - ₹{j.Salary}");
                        }
                        break;

                    case 2:
                        Console.Write("Enter First Name: ");
                        string fname = Console.ReadLine();
                        Console.Write("Enter Last Name: ");
                        string lname = Console.ReadLine();
                        Console.Write("Enter Email: ");
                        string email = Console.ReadLine();
                        if (!email.Contains("@"))
                            throw new InvalidEmailException("Email format is invalid.");
                        Console.Write("Enter Phone: ");
                        string phone = Console.ReadLine();
                        Console.Write("Enter Resume Filename: ");
                        string resume = Console.ReadLine();

                        var applicant = new Applicant
                        {
                            ApplicantID = new Random().Next(1000, 9999),
                            FirstName = fname,
                            LastName = lname,
                            Email = email,
                            Phone = phone,
                            Resume = resume
                        };
                        db.InsertApplicant(applicant);
                        Console.WriteLine("✅ Applicant profile created.");
                        break;

                    case 3:
                        Console.Write("Enter Applicant ID: ");
                        int appId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Job ID: ");
                        int jobId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Cover Letter: ");
                        string coverLetter = Console.ReadLine();

                        var application = new JobApplication
                        {
                            ApplicationID = new Random().Next(1000, 9999),
                            JobID = jobId,
                            ApplicantID = appId,
                            ApplicationDate = DateTime.Now,
                            CoverLetter = coverLetter
                        };
                        db.InsertJobApplication(application);
                        Console.WriteLine("✅ Application submitted.");
                        break;

                    case 4:
                        Console.Write("Enter Company ID: ");
                        int compId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Job Title: ");
                        string title = Console.ReadLine();
                        Console.Write("Enter Description: ");
                        string desc = Console.ReadLine();
                        Console.Write("Enter Location: ");
                        string loc = Console.ReadLine();
                        Console.Write("Enter Salary: ");
                        decimal salary = Convert.ToDecimal(Console.ReadLine());
                        if (salary < 0)
                            throw new NegativeSalaryException("Salary cannot be negative.");
                        Console.Write("Enter Job Type: ");
                        string type = Console.ReadLine();

                        var jobPosting = new JobListing
                        {
                            JobID = new Random().Next(1000, 9999),
                            CompanyID = compId,
                            JobTitle = title,
                            JobDescription = desc,
                            JobLocation = loc,
                            Salary = salary,
                            JobType = type,
                            PostedDate = DateTime.Now
                        };
                        db.InsertJobListing(jobPosting);
                        Console.WriteLine(" Job posted.");
                        break;

                    case 5:
                        Console.Write("Enter Min Salary: ");
                        decimal min = Convert.ToDecimal(Console.ReadLine());
                        Console.Write("Enter Max Salary: ");
                        decimal max = Convert.ToDecimal(Console.ReadLine());
                        var matchedJobs = db.GetJobsBySalaryRange(min, max);
                        if (matchedJobs.Count == 0)
                        {
                            Console.WriteLine("⚠️ No jobs found in that range.");
                        }
                        else
                        {
                            foreach (var j in matchedJobs)
                                Console.WriteLine($"{j.JobTitle} at {j.CompanyName} - ₹{j.Salary}");
                        }
                        break;

                    case 0:
                        Console.WriteLine(" Exiting CareerHub. Goodbye!");
                        return;

                    default:
                        Console.WriteLine(" Invalid choice. Try again.");
                        break;
                }
            }
            catch (InvalidEmailException ex)
            {
                Console.WriteLine($" Email Error: {ex.Message}");
            }
            catch (NegativeSalaryException ex)
            {
                Console.WriteLine($" Salary Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($" An error occurred: {ex.Message}");
            }
        }
    }
}
