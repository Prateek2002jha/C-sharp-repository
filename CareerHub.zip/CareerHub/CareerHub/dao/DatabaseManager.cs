﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using CareerHub.dao;
using CareerHub.Entity;
using CareerHub.Util;

namespace dao
{
    public class DatabaseManager : IDatabaseManager
    {
        private readonly string configFile = "appsettings.json";

        public void InsertCompany(Company company)
        {
            using var conn = DBConnUtil.GetConnection(configFile);
            conn.Open();
            string sql = "INSERT INTO Companies (CompanyID, CompanyName, Location) VALUES (@CompanyID, @CompanyName, @Location)";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@CompanyID", company.CompanyID);
            cmd.Parameters.AddWithValue("@CompanyName", company.CompanyName);
            cmd.Parameters.AddWithValue("@Location", company.Location);
            cmd.ExecuteNonQuery();
        }

        public void InsertJobListing(JobListing job)
        {
            using var conn = DBConnUtil.GetConnection(configFile);
            conn.Open();
            string sql = @"INSERT INTO Jobs (JobID, CompanyID, JobTitle, JobDescription, JobLocation, Salary, JobType, PostedDate) 
                           VALUES (@JobID, @CompanyID, @JobTitle, @JobDescription, @JobLocation, @Salary, @JobType, @PostedDate)";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@JobID", job.JobID);
            cmd.Parameters.AddWithValue("@CompanyID", job.CompanyID);
            cmd.Parameters.AddWithValue("@JobTitle", job.JobTitle);
            cmd.Parameters.AddWithValue("@JobDescription", job.JobDescription);
            cmd.Parameters.AddWithValue("@JobLocation", job.JobLocation);
            cmd.Parameters.AddWithValue("@Salary", job.Salary);
            cmd.Parameters.AddWithValue("@JobType", job.JobType);
            cmd.Parameters.AddWithValue("@PostedDate", job.PostedDate);
            cmd.ExecuteNonQuery();
        }

        public void InsertApplicant(Applicant applicant)
        {
            using var conn = DBConnUtil.GetConnection(configFile);
            conn.Open();
            string sql = @"INSERT INTO Applicants (ApplicantID, FirstName, LastName, Email, Phone, Resume) 
                           VALUES (@ApplicantID, @FirstName, @LastName, @Email, @Phone, @Resume)";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@ApplicantID", applicant.ApplicantID);
            cmd.Parameters.AddWithValue("@FirstName", applicant.FirstName);
            cmd.Parameters.AddWithValue("@LastName", applicant.LastName);
            cmd.Parameters.AddWithValue("@Email", applicant.Email);
            cmd.Parameters.AddWithValue("@Phone", applicant.Phone);
            cmd.Parameters.AddWithValue("@Resume", applicant.Resume);
            cmd.ExecuteNonQuery();
        }

        public void InsertJobApplication(JobApplication application)
        {
            using var conn = DBConnUtil.GetConnection(configFile);
            conn.Open();
            string sql = @"INSERT INTO Applications (ApplicationID, JobID, ApplicantID, ApplicationDate, CoverLetter) 
                           VALUES (@ApplicationID, @JobID, @ApplicantID, @ApplicationDate, @CoverLetter)";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@ApplicationID", application.ApplicationID);
            cmd.Parameters.AddWithValue("@JobID", application.JobID);
            cmd.Parameters.AddWithValue("@ApplicantID", application.ApplicantID);
            cmd.Parameters.AddWithValue("@ApplicationDate", application.ApplicationDate);
            cmd.Parameters.AddWithValue("@CoverLetter", application.CoverLetter);
            cmd.ExecuteNonQuery();
        }

        public List<JobListing> GetJobListings()
        {
            var jobListings = new List<JobListing>();
            using var conn = DBConnUtil.GetConnection(configFile);
            conn.Open();
            string sql = "SELECT * FROM Jobs";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                jobListings.Add(new JobListing
                {
                    JobID = Convert.ToInt32(reader["JobID"]),
                    CompanyID = Convert.ToInt32(reader["CompanyID"]),
                    JobTitle = reader["JobTitle"].ToString(),
                    JobDescription = reader["JobDescription"].ToString(),
                    JobLocation = reader["JobLocation"].ToString(),
                    Salary = Convert.ToDecimal(reader["Salary"]),
                    JobType = reader["JobType"].ToString(),
                    PostedDate = Convert.ToDateTime(reader["PostedDate"])
                });
            }
            return jobListings;
        }

        public List<Company> GetCompanies()
        {
            var companies = new List<Company>();
            using var conn = DBConnUtil.GetConnection(configFile);
            conn.Open();
            string sql = "SELECT * FROM Companies";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                companies.Add(new Company
                {
                    CompanyID = Convert.ToInt32(reader["CompanyID"]),
                    CompanyName = reader["CompanyName"].ToString(),
                    Location = reader["Location"].ToString()
                });
            }
            return companies;
        }

        public List<Applicant> GetApplicants()
        {
            var applicants = new List<Applicant>();
            using var conn = DBConnUtil.GetConnection(configFile);
            conn.Open();
            string sql = "SELECT * FROM Applicants";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                applicants.Add(new Applicant
                {
                    ApplicantID = Convert.ToInt32(reader["ApplicantID"]),
                    FirstName = reader["FirstName"].ToString(),
                    LastName = reader["LastName"].ToString(),
                    Email = reader["Email"].ToString(),
                    Phone = reader["Phone"].ToString(),
                    Resume = reader["Resume"].ToString()
                });
            }
            return applicants;
        }

        public List<JobApplication> GetApplicationsForJob(int jobID)
        {
            var applications = new List<JobApplication>();
            using var conn = DBConnUtil.GetConnection(configFile);
            conn.Open();
            string sql = "SELECT * FROM Applications WHERE JobID = @JobID";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@JobID", jobID);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                applications.Add(new JobApplication
                {
                    ApplicationID = Convert.ToInt32(reader["ApplicationID"]),
                    JobID = Convert.ToInt32(reader["JobID"]),
                    ApplicantID = Convert.ToInt32(reader["ApplicantID"]),
                    ApplicationDate = Convert.ToDateTime(reader["ApplicationDate"]),
                    CoverLetter = reader["CoverLetter"].ToString()
                });
            }
            return applications;
        }

        public List<(string JobTitle, string CompanyName, decimal Salary)> GetJobListingsWithCompany()
        {
            var jobList = new List<(string, string, decimal)>();
            using var conn = DBConnUtil.GetConnection(configFile);
            conn.Open();
            string sql = @"SELECT j.JobTitle, c.CompanyName, j.Salary 
                           FROM Jobs j 
                           INNER JOIN Companies c ON j.CompanyID = c.CompanyID";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                jobList.Add((reader["JobTitle"].ToString(), reader["CompanyName"].ToString(), Convert.ToDecimal(reader["Salary"])));
            }
            return jobList;
        }

        public List<(string JobTitle, string CompanyName, decimal Salary)> GetJobsBySalaryRange(decimal minSalary, decimal maxSalary)
        {
            var result = new List<(string, string, decimal)>();
            using var conn = DBConnUtil.GetConnection(configFile);
            conn.Open();
            string sql = @"SELECT j.JobTitle, c.CompanyName, j.Salary 
                           FROM Jobs j 
                           JOIN Companies c ON j.CompanyID = c.CompanyID
                           WHERE j.Salary BETWEEN @Min AND @Max";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Min", minSalary);
            cmd.Parameters.AddWithValue("@Max", maxSalary);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                result.Add((reader["JobTitle"].ToString(), reader["CompanyName"].ToString(), Convert.ToDecimal(reader["Salary"])));
            }
            return result;
        }
    }
}
